<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="http://127.0.0.1:8000/css/reset.css">
    <link rel="stylesheet" href="http://127.0.0.1:8000/css/converter.css">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css" integrity="sha384-b6lVK+yci+bfDmaY1u0zE8YYJt0TZxLEAFyYSLHId4xoVvsrQu3INevFKo+Xir8e" crossorigin="anonymous">
</head>
<body>
    <div class="row vw-100 overflow-hidden max-vh-100">
        <div class="col-md-7 col-12 left-section d-flex flex-column align-items-center justify-content-md-center justify-content-start gap-4">
            
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="container w-100 d-flex flex-column align-items-center justify-content-center gap-4">
                <div class="title">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <form action="<?php echo e(route('converter.conversion')); ?>" method="POST" class="w-100 d-flex flex-column align-items-center justify-content-center gap-4">
                    <?php echo csrf_field(); ?>
                    <div class="amount-wrapper w-100 d-flex flex-column align-items-center justify-content-center">
                        <label for="amount" class="form-label">Amount</label>
                        <input type="number" id="amount" class="form-control text-center rounded-pill w-75" name="amount" value="<?php echo e(session('amount') ?? ''); ?>">
                    </div>
                    <div class="converter-wrapper w-100 d-flex flex-column align-items-center justify-content-center gap-3">
                        <div class="from-converter-wrapper w-100 d-flex flex-column align-items-center justify-content-center">
                            <label for="from" class="form-label">From</label>
                            <select name="from" id="from" class="form-select rounded-pill text-center w-75">
                                <?php $__currentLoopData = $converters['uniqueFromCurrencies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $description = $converters['uniqueFromCurrenciesDescription'][$key];
                                        $selected = optional(session('converter'))['from_currency'] === $value ? 'selected' : '';
                                    ?>
                                    <option value="<?php echo e($value); ?>" <?php echo e($selected); ?>><?php echo e($value); ?> - <?php echo e($description); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="buttons">
                            <button id="reverse" type="button" class="btn btn-light rounded-pill"><i class="bi bi-arrow-down-up"></i></button>
                        </div>
                        <div class="to-converter-wrapper w-100 d-flex flex-column align-items-center justify-content-center">
                            <label for="to" class="form-label">To</label>
                            <select name="to" id="to" class="form-select rounded-pill text-center w-75">
                                <?php $__currentLoopData = $converters['uniqueToCurrencies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $description = $converters['uniqueToCurrenciesDescription'][$key];
                                        $selected = optional(session('converter'))['to_currency'] === $value ? 'selected' : '';
                                    ?>
                                    <option value="<?php echo e($value); ?>" <?php echo e($selected); ?>><?php echo e($value); ?> - <?php echo e($description); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="buttons w-75">
                        <button type="submit" id="convert" class="btn btn-primary rounded-pill w-100">Convert</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-5 col-12 right-section d-flex flex-column justify-content-md-center justify-content-start text-light">
            
            <div class="container d-flex flex-column justify-content-center text-light">
                <div class="result-wrapper d-flex flex-column align-items-md-end align-items-center">
                    <label class="result display-6 fw-normal" id="from-result">
                        <?php if(session('converter')): ?>
                            <?php echo e(session('converter')['from_currency_symbol']); ?> <?php echo e(session('amount')); ?>

                        <?php else: ?>
                            $ 100
                        <?php endif; ?>
                    </label>
                    <label class="currency h4 fw-normal fst-italic" id="from-currency">
                        <?php if(session('converter')): ?>
                            <?php echo e(session('converter')['from_currency']); ?>

                        <?php else: ?>
                            USD
                        <?php endif; ?>
                    </label>
                </div>
                <div class="result-wrapper d-flex flex-column align-items-md-end align-items-center">
                    <label class="result display-6 fw-normal" id="to-result">
                        <?php if(session('result')): ?>
                            <?php echo e(session('converter')['to_currency_symbol']); ?> <?php echo e(number_format(session('result'), 2, ',', '.')); ?>

                        <?php else: ?>
                        Rp 1.500.000
                        <?php endif; ?>
                    </label>
                    <label class="currency h4 fw-normal fst-italic" id="to-currency">
                        <?php if(session('converter')): ?>
                            <?php echo e(session('converter')['to_currency']); ?>

                        <?php else: ?>
                        IDR
                        <?php endif; ?>
                    </label>
                </div>
                <label class="exchange-rate d-flex flex-column align-items-md-end align-items-center h4 fw-normal" id="exchange-rate">
                    <?php if(session('result')): ?>
                        <?php echo e(session('amount')); ?> <?php echo e(session('converter')['from_currency']); ?> = <?php echo e(number_format(session('result'), 2, ',', '.')); ?> <?php echo e(session('converter')['to_currency']); ?>

                    <?php else: ?>
                        1 USD = 15.000 IDR
                    <?php endif; ?>
                </label>
            </div>
        </div>
        <!-- Add the following lines to show login/register links -->
        <?php if(Route::has('login')): ?>
        <div class="w-100 d-flex flex-row justify-content-end position-fixed">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/converter')); ?>" class="mx-2 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white link-light py-3">Converter Home</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="mx-2 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">Log in</a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="mx-2 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">Register</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <!-- End login/register links -->
    </div>
    <!-- JQUERY -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <script src="http://127.0.0.1:8000/js/converter.js"></script>
</body>
</html>
<?php /**PATH C:\xampp7\htdocs\pemrograman web\Pertemuan 13 Downgrade\resources\views/converter-database.blade.php ENDPATH**/ ?>