<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <?php echo e(__($title)); ?>

                    <a href="<?php echo e(route('converter.create')); ?>" class="btn btn-primary float-end"><i class="bi bi-plus-circle"></i> Add New Converter</a>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th scope="col">From Currency</th>
                                <th scope="col">From Currency Description</th>
                                <th scope="col">To Currency</th>
                                <th scope="col">To Currency Description</th>
                                <th scope="col">Conversion Rate</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $converters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $converter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($converter->from_currency); ?></td>
                                <td><?php echo e($converter->from_currency_description); ?></td>
                                <td><?php echo e($converter->to_currency); ?></td>
                                <td><?php echo e($converter->to_currency_description); ?></td>
                                <td><?php echo e($converter->conversion_rate); ?></td>
                                <td class="flex">
                                    <a href="<?php echo e(route('converter.edit', $converter->id)); ?>" class="btn btn-primary"><i class="bi bi-pencil-square"></i></a>
                                    <form action="<?php echo e(route('converter.destroy', $converter->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')"><i class="bi bi-x-circle"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                        <tfoot>
                            <tr>
                                <td colspan="6" class="flex mx-auto">
                                    <?php echo e($converters->links()); ?>

                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\pemrograman web\Pertemuan 13 Downgrade\resources\views/home.blade.php ENDPATH**/ ?>