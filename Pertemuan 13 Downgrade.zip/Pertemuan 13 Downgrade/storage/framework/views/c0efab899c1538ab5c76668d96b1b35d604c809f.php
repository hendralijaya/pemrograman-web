<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2021 &copy; Pradita University</p>
        </div>
        <div class="float-end">
            <p>
                Crafted with
                <span class="text-danger"
                    ><i class="bi bi-heart"></i
                ></span>
                by Kelompok 1</a>
            </p>
        </div>
    </div>
</footer><?php /**PATH C:\Patricia Ho\Coding\Laravel\pemantauan_kota\resources\views/patrials/footer.blade.php ENDPATH**/ ?>